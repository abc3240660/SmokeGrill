#ifndef __temp_H
#define __temp_H	
#include "sys.h"
int Get_Temperature(u8 channel); 


 
#endif 
