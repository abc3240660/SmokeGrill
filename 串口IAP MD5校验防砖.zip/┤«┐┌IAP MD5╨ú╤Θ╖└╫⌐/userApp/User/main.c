#include <string.h>
#include <stdio.h>
#include <stdbool.h>
#include "Hal_Usart/hal_uart.h"
#include "Hal_Stmflash/hal_stmflash.h" 
#include "Hal_Watchdog/hal_watchdog.h"

u16 oldcount=0;				//前一个串口接收到的数据计数值
u16 applenth=0;				//接收到的APP代码字节长度
u16 lastapplenth=1024*10;		//前一次接收到的APP代码字节长度
u16 package_count=0;	//接收到的APP代码包编号
uint32_t    timeMs;		//系统毫秒计时维护变量，溢出自动为0
extern uint32_t Last_APP_addr;

//开启所有中断
void INTX_ENABLE(void)
{
	__ASM volatile("cpsie i");		  
}

	
uint32_t GetTimerCount(void)
{
		return  timeMs;
}

/**
* @brief TIM2中断函数

* 定时器TIM2的中断函数内完成多按键检测逻辑
* @param none
* @return none
*/
void TIM2_IRQHandler(void)
{
    if (TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET)  
    {
        TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
			  timeMs++;
    }
}

/**
* @brief 定时器初始化
* 使用定时器TIM2 用来监测按键状态
* @param none
* @return none
*/
void timer2Init(void)
{
    u16 arr = 7199; //重装初值
    u16 psc = 9; //预分频
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE); //时钟使能

    //定时器TIM2初始化
    TIM_TimeBaseStructure.TIM_Period = arr; //设置在下一个更新事件装入活动的自动重载寄存器周期的值
    TIM_TimeBaseStructure.TIM_Prescaler = psc; //设置用来作为TIMx时钟频率的预分频值
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1; //设置时钟分割:TDTS = Tck_tim
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;  //TIM向上计数模式
    TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure); //根据指定的参数初始化TIMx的时间基数单位0

    TIM_ITConfig(TIM2, TIM_IT_Update,ENABLE ); //使能指定的TIM2中断,允许更新中断

    //中断优先级NVIC设置
    NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;  //TIM2中断
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;  //优占优先级0级
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;  //从优先级2级
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE; //IRQ通道被使能
    NVIC_Init(&NVIC_InitStructure);  //初始化NVIC寄存器
    TIM_Cmd(TIM2, ENABLE);  //使能TIMx
}	

/**
* 用户初始化函数

* 在该函数中完成了外设驱动初始化以及用户相关数据的初始
* @param none
* @return none
* @note 开发者可在此函数内添加新的驱动初始及状态初始化
*/
void userInit(void)
{
    uartxInit();        //printf打印串口初始化
	  timer2Init();

}

/**
* 用户数据获取

* @param none
* @return none
*/
//void userHandle(void)
//{
//		if(USART_RX_CNT)
//		{
//				if(USART_RX_CNT==oldcount)//新周期内，没有收到任何数据，认为本次数据接收完成
//				{		
//						applenth=USART_RX_CNT;
//						if(applenth>0&&applenth<10)
//						{
//										if(USART_RX_BUF[0]=='s'&&USART_RX_BUF[1]=='k'&&USART_RX_BUF[2]=='i'&&USART_RX_BUF[3]=='p')
//										{//串口收到skip字符串，直接判断进入APP
//													
//										}
//										else
//										{
//													if(package_count==0)	//第一个包不可能只有10字节内大小
//													{
//																printf("input 'skip' to running APP \r\n");
//																Last_Rec_APP_Count=GetTimerCount();
//																oldcount=0;
//																USART_RX_CNT=0;
//																applenth=0;
//																return;
//													}
//										
//										}
//						}
//						if(applenth>0&&lastapplenth<1024*10) //前一次接收到的字节小于1024*10 并且此次有新数据接收到，则表示上次接收数据出错
//						{
//										printf("Receive err, MCU restart...  \r\n");
//										FLASH_ErasePage(STM32_FLASH_BASE);//清除flash首扇区部分代码 
//										SCB->AIRCR =0X05FA0000|(u32)0x04;   //MCU软复位
//						}
//						
//						lastapplenth=applenth;
//						oldcount=0;
//						USART_RX_CNT=0;
//						printf("code lenth:%dBytes\r\n",applenth);
//							
//						if(package_count==0)
//						{
//								printf("FLASH_APP_addr_start:%x\r\n",STM32_FLASH_BASE);
//								writeAppBin(STM32_FLASH_BASE,USART_RX_BUF,applenth);//更新flash代码 
//						}
//						else
//						{
//								writeAppBin(Last_APP_addr,USART_RX_BUF,applenth);//更新flash代码 
//						} 
//						applenth=0;
//						package_count++;
//						printf("FLASH_APP_addr_stop :%x    --%d\r\n",Last_APP_addr,package_count);											
//						
//						Last_Rec_APP_Count=GetTimerCount();		//接收到数据后重新计时60s
//				}
//				else oldcount=USART_RX_CNT;			
//		}
//		
//}

/**
* @brief程序入口函数

* 在该函数中完成用户相关的初始化,及主逻辑循环
* @param none
* @return none
*/
int main(void)
{
    SystemInit();
		INTX_ENABLE();
    userInit();
//		watchdogInit(5);    //watchdog reset time :5s
		uartRbInit();
	
    while(1)
    {     
				watchdogFeed();
			
//        userHandle();			
	
				uartHandle();
			
//				if((GetTimerCount()-Last_Rec_APP_Count)>60000)		//60s未收到升级包便自动运行FLASH_APP
//				{				
//						if(((*(vu32*)(STM32_FLASH_BASE+4))&0xFF000000)==0x08000000)//判断是否为0X08XXXXXX
//						{	 
//									
//						}
//						else
//						{
//									printf("NO APP bin ! please updata...\r\n");
//									Last_Rec_APP_Count=GetTimerCount();
//						}
//				}
    }
}
