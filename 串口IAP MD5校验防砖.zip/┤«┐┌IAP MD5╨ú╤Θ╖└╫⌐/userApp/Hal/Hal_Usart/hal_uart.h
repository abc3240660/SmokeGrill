#ifndef _HAL_UART_H
#define _HAL_UART_H

#include <stdio.h>
#include <stm32f10x.h>
#include "gagent_md5.h"

#define DEBUG

#define	PIECE_MAX_LEN   1024

#define	UART_MAX_LEN   1024*5
#define UART_RB_MAX_LEN         1024*5+1						     ///< Maximum length of ring buffer

#define FILE_MD5_MAX_LEN  32
#define SSL_MAX_LEN (FILE_MD5_MAX_LEN/2)

/*********OTA**********/

typedef enum
{
    CMD_ERR           = 0xa0,             ///< command code error
    CMD_UPDATAPAR     = 0xa1,             ///< updata parameter
    CMD_GETPACKAGE    = 0xa2,             ///< get one IAP package
} errorPacketsType_t;

typedef struct
{
    uint16_t rom_statue;
    uint32_t rom_size;
    uint8_t  ssl_data[SSL_MAX_LEN];
} updateParamSave_t;

typedef struct
{
    uint8_t otaBusyModeFlag;
    uint32_t updateFileSize;	//Rom Size
    MD5_CTX ctx;
    updateParamSave_t update_param;//Save Update Param
} mcuOTA_t;

typedef struct
{
    uint8_t uartIssuedFlag;                             ///< P0 action type
    uint8_t uartProtocolBuf[UART_MAX_LEN];           ///< Protocol data handle buffer
    
}uartProtocol_t; 

#pragma pack()
	
void uartxInit(void);
void uartRbInit(void);
int8_t uartHandle(void);

#endif /*_HAL_UART_H*/
	  	  	
