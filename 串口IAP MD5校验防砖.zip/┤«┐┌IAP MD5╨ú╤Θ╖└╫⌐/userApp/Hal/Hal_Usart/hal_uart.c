#include "Hal_Usart/hal_uart.h"
#include "ringBuffer.h"
#include "Hal_Stmflash/hal_stmflash.h" 
#include "stdbool.h"

uartProtocol_t uartProtocol;                                             ///< Ring buffer structure variable
rb_t uartDataPRb;                                     ///< Ring buffer structure variable
static uint8_t uartDataRbBuf[UART_RB_MAX_LEN]; 
bool packageSendFlag = false;
mcuOTA_t	romUpdate;

#ifdef __GNUC__
// With GCC/RAISONANCE, small printf (option LD Linker->Libraries->Small printf set to 'Yes') calls __io_putchar()
#define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#else
#define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#endif /* __GNUC__ */

/**
* @brief 串口GPIO初始化

* @param none
* @return none
*/
void uartGpioInit(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

}

/**
* @brief 串口配置初始化

* @param none
* @return none
*/
void uartConfig(void)
{
    USART_InitTypeDef USART_InitStructure;

    USART_InitStructure.USART_BaudRate = 115200;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    USART_Init(USART1, &USART_InitStructure);

    USART_ITConfig(USART1,USART_IT_RXNE,ENABLE);
    USART_Cmd(USART1, ENABLE);
    USART_ClearFlag(USART1, USART_FLAG_TC); /*清空发送完成标志,Transmission Complete flag */

}

/**
* @brief 串口NVIC初始化

* @param none
* @return none
*/
void nvicConfiguration(void)
{
    NVIC_InitTypeDef NVIC_InitStructure;
	
    /*使能串口中断,并设置优先级*/
    NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

}

/**
* @brief 串口初始化函数
* @param none
* @return none
*/
void uartxInit(void)
{
    uartGpioInit();
    uartConfig();
    nvicConfiguration();
}

/**
* @brief printf打印重定向
* @param none
* @return none
*/
PUTCHAR_PROTOTYPE
{
    //Place your implementation of fputc here , e.g. write a character to the USART
    USART_SendData(USART1,(u8)ch);
    //Loop until the end of transmission
    while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);
    return ch;
}

void mcuRestart(void)
{
    __set_FAULTMASK(1);
    NVIC_SystemReset();
}

/**
* @brief Character to binary
* @param[in]   A  : Character A
* @param[out]  B  : Character B
* @return     : Accounting for one byte of binary data
*/
uint8_t ICACHE_FLASH_ATTR char2hex(char A , char B)
{
    uint8_t a ,b = 0;
    if(A>='0'&&A<='9')
    {
        a=A-'0';
    }
    else if(A>='A' && A<='F')
    {
        a=A-'A'+10;
    }
    else if(A>='a' && A<='f')
    {
        a=A-'a'+10;
    }

    if(B>='0'&&B<='9')
    {
        b=B-'0';
    }
    else if(B>='A' && B<='F')
    {
        b=B-'A'+10;
    }
    else if( B>='a' && B<='f')
    {
        b=B-'a'+10;
    }

    return (a<<4)+b;
}

/**
* @brief Write data to the ring buffer
* @param [in] buf        : buf adress
* @param [in] len        : byte length
* @return   correct : Returns the length of the written data
            failure : -1
*/
int32_t uartPutData(uint8_t *buf, uint32_t len)
{
    int32_t count = 0;

    if(NULL == buf)
    {
        printf("ERR: uartPutData buf is empty \n");
        return -1;
    }

    count = rbWrite(&uartDataPRb, buf, len);
    if(count != len)
    {
        printf("ERR: Failed to rbWrite \n");
        return -1;
    }

    return count;
}

void USART1_IRQHandler(void)
{
		u8 res;	
		if(USART1->SR&(1<<5))//接收到数据（读取USARTx->SR能避免莫名其妙的错误）
		{	 
				res=USART1->DR; 
				uartPutData(&res, 1);
		}
}

/**
* @brief user Protocol initialization interface

* Protocol-related timer, serial port initialization

* Datapoint initialization

* @param none
* @return none
*/
void uartRbInit(void)
{ 
		uartDataPRb.rbCapacity = UART_RB_MAX_LEN;
    uartDataPRb.rbBuff = uartDataRbBuf;
    if(0 == rbCreate(&uartDataPRb))
		{
			printf("uartDataRb Create Success \r\n");
		}
		else
		{
			printf("uartDataRb Create Faild \r\n");
		}
    
    memset((uint8_t *)&uartProtocol, 0, sizeof(uartProtocol_t));
}

/**
* @brief Get a packet of data from the ring buffer
*
* @param [in]  rb                  : Input data address
* @param [out] data                : Output data address
* @param [out] len                 : Output data length
*
* @return : 0,Return correct ;-1，Return failure;-2，Data check failure
*/
static int8_t uartProtocolGetOnePacket(rb_t *rb, uint8_t *uartdata, uint16_t *len)
{
    int32_t ret = 0;
    int32_t i = 0;
    uint8_t tmpData;
    uint8_t tmpLen = 0;
    static uint8_t protocolFlag = 0;
    static uint16_t protocolCount = 0;
		static uint16_t count = 0;
    uint8_t *protocolBuff = uartdata;
		static uint8_t data1 = 0;
		static uint8_t data2 = 0;
		static uint8_t data3 = 0;
  

    if((NULL == rb) || (NULL == uartdata) ||(NULL == len))
    {
        printf("uartProtocolGetOnePacket Error , Illegal Param\n");
        return -1;
    }

    tmpLen = rbCanRead(rb);
    if(0 == tmpLen)
    {
        return -1;
    }

    for(i=0; i<tmpLen; i++)
    {
        ret = rbRead(rb, &tmpData, 1);
        if(0 != ret)
        {
						count++;
						if(count == 1){data1=tmpData;}
						else if(count == 2){data2=data1;data1=tmpData;}
						else if(count == 3){count=2;data3=data2;data2=data1;data1=tmpData;}
			
            if(('S'==data3)&&('T'==data2)&&('A'==data1))protocolFlag = 1;
            else
            {
                if(1 == protocolFlag)
                {
                    protocolBuff[protocolCount] = tmpData;
                    protocolCount++;

                    if(protocolCount > 3)
                    {
                        if(('E'==data3)&&('N'==data2)&&('D'==data1))
                        {
														protocolCount-=3;
														memcpy(uartdata, protocolBuff, protocolCount);
														*len = protocolCount;
														protocolCount = 0;
														protocolFlag = 0;
														count = 0;
														return 1;
                        }
                    }
                }
            }

        }
    }

    return 0;
}

/**
* @brief UpdateCmdHandle

* Handle OTA Ask , Transform MD5 Char2Hex

* @param[in]  :
* @param[out] :
* @return  0,Update Ask Handle Success , Send Ready Success
*					-1,Input Param Illegal
*					-2,Update Ask Handle Success , Send Ready Faild
*
*/
int8_t updateParHandle(uint8_t *inData,uint16_t dataLen)
{
    uint8_t k = 0;
		uint8_t binSize[2];

    if(dataLen < 6)
    {
        return -1;
    }
		
		for(uint16_t j = 0; j<2; j++)
    {
        binSize[j] = char2hex(inData[k+2],inData[k+1+2]);
        k += 2;
    }
    romUpdate.updateFileSize = (((uint32_t)(binSize[0]<<8))|((uint32_t)(binSize[1])));

    //judge flash size
    if(romUpdate.updateFileSize > APP_BAK_DATA_MAX_SIZE)
    {
        printf("UpdateFileSize Error ,Update Failed ,fileSize = %d \r\n",romUpdate.updateFileSize);
        return -1;
    }
    else
    {
        printf("UpdateFileSize Legal ,size = %d \r\n",romUpdate.updateFileSize);
        romUpdate.update_param.rom_size = romUpdate.updateFileSize;
//      flash_erase(APP_BAK_DATA_MAX_SIZE,SYS_APP_BAK_SAVE_ADDR_BASE);
//			printf("flash erase finished!!\n");
    }

		k=0;
    for(uint16_t j = 0; j<SSL_MAX_LEN; j++)
    {
        romUpdate.update_param.ssl_data[j] = char2hex(inData[k+6],inData[k+1+6]);
        k += 2;
    }
#ifdef DEBUG
    printf("MD5_Hex: ");
    for(uint16_t i=0; i<SSL_MAX_LEN; i++)
    {
        printf("%02x ", romUpdate.update_param.ssl_data[i]);
    }
    printf("\r\n");
#endif
    GAgent_MD5Init(&romUpdate.ctx);

    //send ready
    printf("Please Send IAP the 1 Package \r\n");
	
///************写入升级参数********************/		
//		if(!currentDataPoint.valuedestMoudleIapFlag)
//		{
//				romUpdate.update_param.rom_statue = 0xEEEE;//自身IAP
//				STMFLASH_Write(UPDATE_PARAM_SAVE_ADDR_BASE, (uint16_t *)&romUpdate.update_param, sizeof(updateParamSave_t));	
//		}
					
    return 0;
}

/**
* @brief Protocol handling function

* 

* @param [in] currentData :The protocol data pointer
* @return none
*/
int8_t uartHandle(void)
{
    int8_t ret = 0;
#ifdef DEBUG
    uint16_t i = 0;
#endif
    uint16_t protocolLen = 0;
		static uint8_t packageCount = 0;
	  uint8_t cmdBuf =0;
		uint16_t tmpLen = 0;
		uint8_t md5_calc[SSL_MAX_LEN];//MD5 Calculate Fact
		uint8_t tmpData[PIECE_MAX_LEN];
		static uint8_t count =0;
  
    if(!packageSendFlag)ret = uartProtocolGetOnePacket(&uartDataPRb, uartProtocol.uartProtocolBuf, &protocolLen);
  
		if(1 == ret)
    {
        printf("Get One Packet!\r\n");
        
#ifdef  DEBUG
        for(i=0; i<protocolLen;i++)
        {
            printf("%02x ", uartProtocol.uartProtocolBuf[i]);
        }
        printf("\r\n");
#endif
				
				cmdBuf = char2hex(uartProtocol.uartProtocolBuf[0],uartProtocol.uartProtocolBuf[1]);
				printf("cmdBuf:%x \r\n",cmdBuf);
				switch(cmdBuf)
				{
						case CMD_UPDATAPAR:
								updateParHandle(uartProtocol.uartProtocolBuf,protocolLen);
								packageSendFlag = true;
								break;
						case CMD_GETPACKAGE:
								break;
						case CMD_ERR:
								printf("***input cmd err,check and resend \r\n");
								break;
						default:
								break;
				}
				
    }
		
		if(packageSendFlag)
		{
				
				tmpLen = (uint16_t)rbCanRead(&uartDataPRb);
				if(0 == tmpLen)return -2;
				if(tmpLen == UART_MAX_LEN)
				{		
						count++;
						while((uint8_t)(tmpLen/PIECE_MAX_LEN))
						{	
								memset(tmpData,0,PIECE_MAX_LEN);
								rbRead(&uartDataPRb,tmpData,PIECE_MAX_LEN);
								writeAppBin(SYS_APP_BAK_SAVE_ADDR_BASE+packageCount*PIECE_MAX_LEN,tmpData,PIECE_MAX_LEN);//更新flash代码 
								GAgent_MD5Update(&romUpdate.ctx, tmpData, PIECE_MAX_LEN);
								tmpLen-=PIECE_MAX_LEN;
								packageCount++;
						}
						printf("please send the %d package\r\n",count+1);
				}
				if(tmpLen == (romUpdate.updateFileSize-packageCount*PIECE_MAX_LEN)) //最后一包数据
				{
						while((uint8_t)(tmpLen/PIECE_MAX_LEN))
						{
								memset(tmpData,0,PIECE_MAX_LEN);
								rbRead(&uartDataPRb,tmpData,PIECE_MAX_LEN);
								writeAppBin(SYS_APP_BAK_SAVE_ADDR_BASE+packageCount*PIECE_MAX_LEN,tmpData,PIECE_MAX_LEN);//更新flash代码 
								GAgent_MD5Update(&romUpdate.ctx, tmpData, PIECE_MAX_LEN);
								tmpLen-=PIECE_MAX_LEN;
								packageCount++;
						}
						packageSendFlag=false;
						memset(tmpData,0,tmpLen);
						rbRead(&uartDataPRb,tmpData,tmpLen);
						writeAppBin(SYS_APP_BAK_SAVE_ADDR_BASE+packageCount*PIECE_MAX_LEN,tmpData,tmpLen);//更新flash代码 
						GAgent_MD5Update(&romUpdate.ctx, tmpData, tmpLen);
						memset(md5_calc,0,SSL_MAX_LEN);
						GAgent_MD5Final(&romUpdate.ctx, md5_calc);
						printf("MD5 Calculate Success , Will Check The MD5 ..\r\n ");
						packageCount=0;
						count=0;
						if(0 != memcmp(romUpdate.update_param.ssl_data, md5_calc, SSL_MAX_LEN))
						{
								printf("Md5_Cacl Check Faild ,MCU OTA Faild\r\n ");
#ifdef DEBUG
								printf("Calc MD5: ");
								for(uint16_t i=0; i<SSL_MAX_LEN; i++)
								{
										printf("%02x ", md5_calc[i]);
								}
								printf("\r\n");
#endif
#ifdef DEBUG
								printf("SSL MD5: ");
								for(uint16_t i=0; i<SSL_MAX_LEN; i++)
								{
										printf("%02x ", romUpdate.update_param.ssl_data[i]);
								}
								printf("\r\n");
#endif
								memset((uint8_t *)&romUpdate.update_param,0,sizeof(updateParamSave_t));
								return -2;
						}
						else
						{
								printf("MD5 Check Success ,Write Update Flag \r\n ");
								romUpdate.update_param.rom_statue = 0xDDDD;//升级对象不同，标志参数不同
		            STMFLASH_Write(UPDATE_PARAM_SAVE_ADDR_BASE, (uint16_t *)&romUpdate.update_param, sizeof(updateParamSave_t)/2);	
								printf("System Will Restart... \n");
			          /****************************MCU RESTART****************************/
								mcuRestart();
								/******************************************************************************/
								//last package , updata ok
								//MD5 checkout :Failed clear updata,Success , write flash ,begin updata
						}
				
				}
					
				
		}

    return 0;
}

