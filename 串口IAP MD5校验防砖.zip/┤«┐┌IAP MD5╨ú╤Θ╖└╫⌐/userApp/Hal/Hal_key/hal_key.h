#ifndef _HAL_KEY_H
#define _HAL_KEY_H

#include <stdbool.h>
#include <stdio.h>
#include <stm32f10x.h>

#define G_SET_BIT(a,b)                            (a |= (1 << b))
#define G_CLEAR_BIT(a,b)                          (a &= ~(1 << b))
#define G_IS_BIT_SET(a,b)                         (a & (1 << b))

#define KEY_TIMER_MS                            1
#define KEY_MAX_NUMBER                          12
#define DEBOUNCE_TIME                           30
#define PRESS_LONG_TIME                         3000

#define NO_KEY                                  0x0000
#define KEY_DOWN                                0x1000
#define KEY_UP                                  0x2000
#define KEY_LIAN                                0x4000
#define KEY_LONG                                0x8000

#define KEY_DELAY_TIME_MAX	200		//按键LED闪烁间隔时长
#define KEY_LED_COUNT_MAX	6		//按键LED闪烁次数

typedef void (*gokitKeyFunction)(void);

__packed typedef struct
{
    uint8_t          keyNum;
    uint32_t         keyRccPeriph;
    GPIO_TypeDef     *keyPort;
    uint32_t         keyGpio;
    gokitKeyFunction shortPress; 
    gokitKeyFunction longPress; 
}keyTypedef_t;

__packed typedef struct
{
    uint8_t      keyTotolNum;
    keyTypedef_t *singleKey; 
}keysTypedef_t; 

__packed typedef struct
{
    uint32_t         timeMs;
}keytimeCount_t;

__packed typedef struct
{
		bool				keylongcount;
		bool				keylongturn;
		uint8_t			keylongtemp;
    uint32_t    irLasttimeMs;
}keyxlong_t;

void keyGpioInit(void);
void keyHandle(keysTypedef_t *keys);
void keyParaInit(keysTypedef_t *keys);
uint16_t getKey(keysTypedef_t *key);
uint16_t readKeyValue(keysTypedef_t *keys);
keyTypedef_t keyInitOne(uint32_t keyRccPeriph, GPIO_TypeDef * keyPort, uint32_t keyGpio, gokitKeyFunction shortPress, gokitKeyFunction longPress);

void keyxMessageHandle(uint8_t keyx);
uint32_t GetTimerCount(void);
	
#endif /*_HAL_KEY_H*/

